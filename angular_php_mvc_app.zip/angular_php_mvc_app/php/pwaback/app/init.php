<?php
require_once('database.php');
require_once('core/App.php');
require_once('core/Controller.php');