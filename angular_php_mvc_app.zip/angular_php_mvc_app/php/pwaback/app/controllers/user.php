<?php

    class User extends Controller
    {   
        protected $user;

        public function __construct()
        {
            $this->user = $this->model('UserModel');
        }

        public function index()
        {

        }

        public function getPostData()
        {
            return json_decode(file_get_contents('php://input'), true);
        }

        public function rotateEntity($entityArr,$usernameLength,$action){
            $transformedEntity = '';
        
            if($action == 'encrypt'){
                foreach($entityArr as $character){
                    $transformedEntity .= chr(ord($character)+$usernameLength);
                }
            } else if($action == 'decrypt'){
                foreach($entityArr as $character){
                    $transformedEntity .= chr(ord($character)-$usernameLength);
                }
            }           
            return $transformedEntity;
        }

        public function encryptPayload($username,$password,$email='',$contact='')
        {   
            
            $encryptedArr = [];

            $usernameLength = strlen($username);

            $usernameArray = str_split($username);
            $passwordArray = str_split($password);
            
            $encUsername = $this->rotateEntity($usernameArray,$usernameLength,'encrypt');
            $encPassword = $this->rotateEntity($passwordArray,$usernameLength,'encrypt');

            array_push($encryptedArr,$encUsername,$encPassword);

            if(!empty($email) && !empty($contact)){
                $emailArray = str_split($email);
                $contactArray = str_split($contact);
                $encEmail = $this->rotateEntity($emailArray,$usernameLength,'encrypt');
                $encContact = $this->rotateEntity($contactArray,$usernameLength,'encrypt');
                array_push($encryptedArr,$encEmail,$encContact);
            }
        
            return $encryptedArr;

        }

        public function decryptPayload($username,$email,$contact)
        {
            
            $decryptedArr = [];

            $usernameLength = strlen($username);
            $usernameArray = str_split($username);
            $emailArray = str_split($email);
            $contactArray = str_split($contact);

            $decUsername = $this->rotateEntity($usernameArray,$usernameLength,'decrypt');
            $decEmail = $this->rotateEntity($emailArray,$usernameLength,'decrypt');
            $decContact = $this->rotateEntity($contactArray,$usernameLength,'decrypt');

            array_push($decryptedArr,$decUsername,$decEmail,$decContact);

            return $decryptedArr;

        }

        public function register()
        {               
            $registerArray = $this->getPostData();
            extract($registerArray);
            $encryptedPayloadArr = $this->encryptPayload($username,$password,$email,$contact);
            $registerUser = $this->user->registerUser($encryptedPayloadArr[0],$encryptedPayloadArr[1],
            $encryptedPayloadArr[2],$encryptedPayloadArr[3]);
            $registerResponse = '';

            if($registerUser == false){
            	http_response_code(403);
            	$registerResponse = json_encode(array("code"=>403,"message"=>"Username already exists!"));
            } else {
            	$registerResponse = json_encode(array("code"=>200,"message"=>"User Registered"));
            }

            echo $registerResponse;
        
        }

        public function login()
        {   
            $loginArray = $this->getPostData();
            extract($loginArray);
            $encryptedPayloadArr = $this->encryptPayload($username,$password);
            $loginDbResp = $this->user->loginUser($encryptedPayloadArr[0],$encryptedPayloadArr[1]);
            $loginResponse = '';

            if(is_numeric($loginDbResp)){
                $loginResponse = json_encode(array("code"=>200,"message"=>"Login Success","data"=>array("userId"=>$loginDbResp)));
            } else {
            	http_response_code(403);
                $loginResponse = json_encode(array("code"=>403,"message"=>$loginDbResp));
            }

            echo $loginResponse;

        }

        public function profile($id)
        {
            $getUserProfile = $this->user->getUserProfile($id[0]);
            extract($getUserProfile);
            $decryptedPayloadArr = $this->decryptPayload($username,$email,$contact);
            $decryptedPayloadArr = array("username"=>$decryptedPayloadArr[0],"email"=>$decryptedPayloadArr[1],"contact"=>$decryptedPayloadArr[2]);
            echo json_encode(array("code"=>200,"data"=>array("userProfile"=>$decryptedPayloadArr)));
        }

    }

?>