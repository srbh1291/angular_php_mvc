<?php

class UserModel extends Database
{
    private $conn; 

    public function __construct()
	{
        $this->conn = $this->getConnection();
    }
    

    public function removeNonAsciiChars($str) {
        return preg_replace('/[[:^print:]]/', '', $str);
    }

    public function registerUser($username,$password,$email,$contact)
    {       

       $username = $this->removeNonAsciiChars($username);
       $password = $this->removeNonAsciiChars($password);
       $email = $this->removeNonAsciiChars($email);
       $contact = $this->removeNonAsciiChars($contact);

       $count = $this->conn->query("SELECT count(username) FROM user WHERE username='".$username."'")->fetchColumn();
       if($count==0){
            $query = "INSERT INTO user (username,password,email,contact) VALUES (:username,:password,
            :email,:contact)";
            $pdo_statement = $this->conn->prepare($query);
            $result = $pdo_statement->execute(array(':username'=>$username,':password'=>$password, 
            ':email'=>$email,':contact'=>$contact));
            return true;
        } else {
            return false;
        }
    }


    public function loginUser($username,$password)
    {    

        $username = $this->removeNonAsciiChars($username);
        $password = $this->removeNonAsciiChars($password);    

        $query = $this->conn->query("SELECT uid,username,password FROM user WHERE username='".$username."'")->fetch(PDO::FETCH_ASSOC);
        $query['username'] = $query['username'] ?? '';
        $query['password'] = $query['password'] ?? '';

        if($query['username'] == $username && $query['password'] == $password){
            return $query['uid'];
        } else if($query['username'] == $username && $query['password'] != $password){
            return "Password does not match for the username";
        } else if($query['username'] != $username && $query['password'] != $password){
            return "Account does not exists";
        }

    }

    public function getUserProfile($userId)
    {        
        return $query = $this->conn->query("SELECT username,email,contact FROM user WHERE uid='".$userId."'")->fetch(PDO::FETCH_ASSOC);
    }


}


?>