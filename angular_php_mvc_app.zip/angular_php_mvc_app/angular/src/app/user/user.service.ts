import { HttpClient} from '@angular/common/http';
import { IUser } from './userInterface';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
    providedIn: 'root'
})

export class UserService {

    apiPath = '/pwaback/public/user/';
    userLoggedInStatus:boolean=false;

    constructor(private httpClient:HttpClient,private router:Router){}

    setLoggedInStatus(userId){
        this.userLoggedInStatus = true;
        localStorage.setItem('token', userId);
    }

    getLoggedInStatus(){
        const usertoken = localStorage.getItem('token');
        if(usertoken){
            return true
        } else {
            return false;
        }
        
    }

    registerUser(registerDetails:IUser){
        return this.httpClient.post(this.apiPath+'register',registerDetails);
    }

    loginUser(loginCredentials:IUser) {
        return this.httpClient.post(this.apiPath+'login',loginCredentials);  
    }

    getUserDetails(userId){
        return this.httpClient.get(this.apiPath+'profile/'+userId);
    }

    logout(){
        localStorage.removeItem('token');
        // this.userLoggedInStatus = false;
        this.router.navigate(['login']);
    }



}