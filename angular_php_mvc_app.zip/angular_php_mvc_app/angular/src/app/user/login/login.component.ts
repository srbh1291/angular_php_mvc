import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder, Validators } from '@angular/forms';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  isSubmitted: boolean = false;
  loginErr:string = '';
  
  constructor(private fb: FormBuilder,private userService:UserService,private router:Router) { }

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['',  Validators.required]
    });
  }

  onSubmit(){
    this.isSubmitted = true;

    if(this.loginForm.status==='VALID'){
      this.userService.loginUser(this.loginForm.value)
      .subscribe((resp)=>{
          const userId =  resp["data"]["userId"];
          this.userService.setLoggedInStatus(userId);
          this.router.navigate(['profile',userId]);
          if(this.loginErr) this.loginErr = '';
        },err => {
          this.loginErr = err['error']['message'];
        } 
      )
    }

  }


}
