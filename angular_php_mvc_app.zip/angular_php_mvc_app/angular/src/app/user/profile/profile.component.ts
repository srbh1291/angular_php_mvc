import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { ActivatedRoute, Params } from '@angular/router';
import { IUser } from '../userInterface';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})

export class ProfileComponent implements OnInit {
  

  userDetails:IUser;

  constructor(private route:ActivatedRoute,private userService:UserService) { }

  ngOnInit(): void {

    this.route.params
      .subscribe(
        (params: Params) => {
          this.getUserProfileDetails(params['id']);
        }
      );

  }

  getUserProfileDetails(userid) {
    this.userService.getUserDetails(userid)
      .subscribe((resp)=>{
          this.userDetails = resp['data']['userProfile'];
        }
      )
  }

}
